# ─────────────────────────────────────────────────────
#   main.py — CLI Runner (terminal output, no UI)
#   Run: python main.py
# ─────────────────────────────────────────────────────

from agents import (
    WonderScoutAgent,
    ItineraryArchitectAgent,
    CultureChefAgent,
    SafetyGuardianAgent,
    MasterConciergeAgent,
)


def run_travel_concierge(destination: str, days: int = 5):
    print(f"""
╔══════════════════════════════════════════════════════╗
║   🌍 WORLD WONDERS AI TRAVEL CONCIERGE              ║
║   Powered by Groq (FREE) + Llama 3.3 70B            ║
║   Destination : {destination:<36}║
║   Days        : {str(days):<36}║
╚══════════════════════════════════════════════════════╝
    """)

    # ── Specialist Agents ─────────────────────────
    scout_report  = WonderScoutAgent().run(destination=destination)
    itinerary     = ItineraryArchitectAgent().run(destination=destination, scout_report=scout_report, days=days)
    culture_guide = CultureChefAgent().run(destination=destination)
    safety_guide  = SafetyGuardianAgent().run(destination=destination)

    # ── Orchestrator ──────────────────────────────
    final_guide = MasterConciergeAgent().run(
        destination=destination,
        days=days,
        all_reports={
            "WonderScout":        scout_report,
            "ItineraryArchitect": itinerary,
            "CultureChef":        culture_guide,
            "SafetyGuardian":     safety_guide,
        }
    )

    print("\n" + "═" * 60)
    print("✨ YOUR FINAL TRAVEL GUIDE")
    print("═" * 60)
    print(final_guide)
    print("\n✅ Done! Ready to share on LinkedIn 🚀\n")


if __name__ == "__main__":
    # 🌍 Change destination & days here!
    run_travel_concierge("Machu Picchu, Peru", days=5)

    # run_travel_concierge("Taj Mahal, India", days=4)
    # run_travel_concierge("Petra, Jordan", days=4)
    # run_travel_concierge("Great Wall of China", days=7)
    # run_travel_concierge("Santorini, Greece", days=6)