# ─────────────────────────────────────────────────
#   app.py — Streamlit UI
#   Run: streamlit run app.py
# ─────────────────────────────────────────────────

import os
import streamlit as st
from dotenv import load_dotenv

from agents import (
    WonderScoutAgent,
    ItineraryArchitectAgent,
    CultureChefAgent,
    SafetyGuardianAgent,
    MasterConciergeAgent,
)

load_dotenv()

# ── Page Config ─────────────────────────────────
st.set_page_config(
    page_title="🌍 World Wonders AI Concierge",
    page_icon="🗺️",
    layout="wide"
)

# ── Theme Selection (Initialize) ──────────────────
if "theme" not in st.session_state:
    st.session_state.theme = "dark"

# ── Dynamic CSS Styling ──────────────────────────
# Dark Theme
dark_theme_css = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Lato:wght@300;400;700&display=swap');

html, body, [class*="css"] { font-family: 'Lato', sans-serif; }

.stApp {
    background: linear-gradient(135deg, #0a0a1a 0%, #0d1b2a 50%, #1a0a2e 100%);
    color: #e8dcc8;
}
h1, h2, h3 { font-family: 'Playfair Display', serif !important; }

.stButton > button {
    background: rgba(245,208,138,0.08) !important;
    border: 1px solid rgba(245,208,138,0.3) !important;
    color: #f5d08a !important;
    border-radius: 8px !important;
    width: 100% !important;
    transition: all 0.2s !important;
}
.stButton > button:hover {
    background: rgba(245,208,138,0.18) !important;
    transform: translateX(3px) !important;
}
div[data-testid="stFormSubmitButton"] > button {
    background: linear-gradient(135deg, #e8a838, #f5d08a) !important;
    color: #0a0a1a !important;
    font-weight: 700 !important;
    font-size: 1rem !important;
    border: none !important;
    width: 100% !important;
    padding: 0.7rem !important;
    border-radius: 10px !important;
}
[data-testid="stSidebar"] {
    background: rgba(8,8,20,0.97) !important;
    border-right: 1px solid rgba(245,208,138,0.1) !important;
}
.stTextInput > div > div > input {
    background: rgba(255,255,255,0.05) !important;
    border: 1px solid rgba(245,208,138,0.3) !important;
    color: #e8dcc8 !important;
    border-radius: 8px !important;
}
.stTabs [data-baseweb="tab"] {
    color: #7a93aa !important;
}
.stTabs [aria-selected="true"] {
    color: #f5d08a !important;
    border-bottom: 2px solid #f5d08a !important;
}
.stMarkdown {
    color: #e8dcc8 !important;
}
</style>
"""

# Light Theme
light_theme_css = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Lato:wght@300;400;700&display=swap');

html, body, [class*="css"] { font-family: 'Lato', sans-serif; }

.stApp {
    background: linear-gradient(135deg, #f5f5f5 0%, #ffffff 50%, #f0f0f0 100%);
    color: #1a1a1a;
}
h1, h2, h3 { font-family: 'Playfair Display', serif !important; color: #0a3a66 !important; }

.stButton > button {
    background: rgba(10,58,102,0.08) !important;
    border: 1px solid rgba(10,58,102,0.3) !important;
    color: #0a3a66 !important;
    border-radius: 8px !important;
    width: 100% !important;
    transition: all 0.2s !important;
}
.stButton > button:hover {
    background: rgba(10,58,102,0.18) !important;
    transform: translateX(3px) !important;
}
div[data-testid="stFormSubmitButton"] > button {
    background: linear-gradient(135deg, #0a3a66, #1a5fa0) !important;
    color: #ffffff !important;
    font-weight: 700 !important;
    font-size: 1rem !important;
    border: none !important;
    width: 100% !important;
    padding: 0.7rem !important;
    border-radius: 10px !important;
}
[data-testid="stSidebar"] {
    background: rgba(240,240,240,0.97) !important;
    border-right: 1px solid rgba(10,58,102,0.1) !important;
}
.stTextInput > div > div > input {
    background: rgba(255,255,255,0.8) !important;
    border: 1px solid rgba(10,58,102,0.3) !important;
    color: #1a1a1a !important;
    border-radius: 8px !important;
}
.stTabs [data-baseweb="tab"] {
    color: #666666 !important;
}
.stTabs [aria-selected="true"] {
    color: #0a3a66 !important;
    border-bottom: 2px solid #0a3a66 !important;
}
.stMarkdown {
    color: #1a1a1a !important;
}
</style>
"""

# Apply selected theme
if st.session_state.theme == "dark":
    st.markdown(dark_theme_css, unsafe_allow_html=True)
else:
    st.markdown(light_theme_css, unsafe_allow_html=True)


# ══════════════════════════════════════════════
# SIDEBAR
# ══════════════════════════════════════════════
with st.sidebar:
    st.markdown("## 🗺️ AI Travel Concierge")
    st.markdown("*Powered by **Groq** (FREE & Fast)*")
    
    # ── Theme Toggle ──────────────────────────
    theme_col1, theme_col2 = st.columns(2)
    with theme_col1:
        if st.button("🌙 Dark", use_container_width=True, key="dark_theme"):
            st.session_state.theme = "dark"
            st.rerun()
    with theme_col2:
        if st.button("☀️ Light", use_container_width=True, key="light_theme"):
            st.session_state.theme = "light"
            st.rerun()
    
    st.divider()

    # API Key Status (securely loaded from .env)
    st.markdown("**🔑 Groq API Configuration**")
    if os.getenv("GROQ_API_KEY"):
        st.success("✅ API Key is configured and ready!")
        st.caption("*Loaded from environment (secure)*")
    else:
        st.error("❌ Groq API Key not found!")
        st.caption("""
            **Setup Instructions:**
            1. Get a FREE API key from [console.groq.com](https://console.groq.com)
            2. Create a `.env` file in the project root
            3. Add: `GROQ_API_KEY=your_key_here`
            4. Restart the app
        """)

    st.divider()

    # Quick wonder selector
    st.markdown("**🌍 Quick Select a Wonder**")
    wonders = [
        ("🏔️", "Machu Picchu, Peru"),
        ("🏯", "Great Wall of China"),
        ("🌺", "Petra, Jordan"),
        ("🕌", "Taj Mahal, India"),
        ("🏛️", "Colosseum, Rome"),
        ("🌊", "Angkor Wat, Cambodia"),
        ("❄️", "Northern Lights, Iceland"),
        ("🌅", "Santorini, Greece"),
    ]
    for emoji, name in wonders:
        if st.button(f"{emoji} {name}", key=name):
            st.session_state["destination"] = name

    st.divider()

    # Agent status
    st.markdown("**🤖 Agent Team Status**")
    agents_info = [
        ("🔍", "WonderScoutAgent"),
        ("📅", "ItineraryArchitectAgent"),
        ("🍽️", "CultureChefAgent"),
        ("⚠️", "SafetyGuardianAgent"),
        ("✨", "MasterConciergeAgent"),
    ]
    for emoji, name in agents_info:
        status = st.session_state.get(f"status_{name}", "⚪ Idle")
        st.markdown(f"{emoji} **{name}**  \n{status}")


# ══════════════════════════════════════════════
# MAIN PAGE
# ══════════════════════════════════════════════
st.markdown("# 🌍 World Wonders AI Travel Concierge")
st.markdown("#### ✦ 5 Specialized AI Agents &nbsp;·&nbsp; Multi-Agent Architecture &nbsp;·&nbsp; Powered by Groq (FREE) ✦")

# Agent pipeline visual
st.markdown("""
> 🔍 **WonderScout** → 📅 **Itinerary** → 🍽️ **Culture** → ⚠️ **Safety** → ✨ **Final Guide**
""")
st.divider()

# ── Input Form ───────────────────────────────
with st.form("travel_form"):
    col1, col2 = st.columns([3, 1])
    with col1:
        destination = st.text_input(
            "🗺️ Enter any World Wonder or Destination",
            value=st.session_state.get("destination", ""),
            placeholder="e.g. Machu Picchu Peru · Taj Mahal India · Petra Jordan..."
        )
    with col2:
        days = st.slider("📅 Trip Days", min_value=3, max_value=14, value=5)

    submitted = st.form_submit_button("✈️ Generate My Travel Guide →")


# ══════════════════════════════════════════════
# RUN AGENTS
# ══════════════════════════════════════════════
if submitted:
    if not destination:
        st.warning("⚠️ Please enter a destination!")
        st.stop()

    if not os.getenv("GROQ_API_KEY"):
        st.error("""
        ❌ **Groq API Key not configured!**
        
        **Setup Instructions:**
        1. Get a FREE API key from [console.groq.com](https://console.groq.com)
        2. Create a `.env` file in the project root with:
           ```
           GROQ_API_KEY=your_key_here
           ```
        3. Restart the application
        """)
        st.stop()

    st.divider()
    st.markdown(f"### ✈️ Planning your **{days}-day** adventure to **{destination}**")
    st.caption("5 AI agents are working in sequence — each builds on the previous...")

    # Tabs for each agent output
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "🔍 Scout", "📅 Itinerary", "🍽️ Culture", "⚠️ Safety", "✨ Final Guide"
    ])

    # ── Agent 1 ──────────────────────────────
    with tab1:
        st.markdown("### 🔍 WonderScoutAgent — Destination Intelligence")
        st.session_state["status_WonderScoutAgent"] = "🟡 Running..."
        with st.spinner("WonderScout is researching your destination..."):
            scout = WonderScoutAgent().run(destination=destination)
        st.session_state["status_WonderScoutAgent"] = "🟢 Done"
        st.markdown(scout)
        st.success("✅ WonderScoutAgent complete!")

    # ── Agent 2 ──────────────────────────────
    with tab2:
        st.markdown("### 📅 ItineraryArchitectAgent — Day-by-Day Plan")
        st.session_state["status_ItineraryArchitectAgent"] = "🟡 Running..."
        with st.spinner("ItineraryArchitect is crafting your perfect itinerary..."):
            itinerary = ItineraryArchitectAgent().run(
                destination=destination,
                scout_report=scout,
                days=days
            )
        st.session_state["status_ItineraryArchitectAgent"] = "🟢 Done"
        st.markdown(itinerary)
        st.success("✅ ItineraryArchitectAgent complete!")

    # ── Agent 3 ──────────────────────────────
    with tab3:
        st.markdown("### 🍽️ CultureChefAgent — Food & Culture Guide")
        st.session_state["status_CultureChefAgent"] = "🟡 Running..."
        with st.spinner("CultureChef is exploring local food and customs..."):
            culture = CultureChefAgent().run(destination=destination)
        st.session_state["status_CultureChefAgent"] = "🟢 Done"
        st.markdown(culture)
        st.success("✅ CultureChefAgent complete!")

    # ── Agent 4 ──────────────────────────────
    with tab4:
        st.markdown("### ⚠️ SafetyGuardianAgent — Safety & Practical Tips")
        st.session_state["status_SafetyGuardianAgent"] = "🟡 Running..."
        with st.spinner("SafetyGuardian is checking safety and logistics..."):
            safety = SafetyGuardianAgent().run(destination=destination)
        st.session_state["status_SafetyGuardianAgent"] = "🟢 Done"
        st.markdown(safety)
        st.success("✅ SafetyGuardianAgent complete!")

    # ── Agent 5 — Orchestrator ────────────────
    with tab5:
        st.markdown("### ✨ MasterConciergeAgent — Your Complete Travel Guide")
        st.session_state["status_MasterConciergeAgent"] = "🟡 Running..."
        with st.spinner("MasterConcierge is synthesizing everything into your perfect guide..."):
            final = MasterConciergeAgent().run(
                destination=destination,
                days=days,
                all_reports={
                    "WonderScout":        scout,
                    "ItineraryArchitect": itinerary,
                    "CultureChef":        culture,
                    "SafetyGuardian":     safety,
                }
            )
        st.session_state["status_MasterConciergeAgent"] = "🟢 Done"
        st.markdown(final)
        st.success("🎉 Your complete travel guide is ready!")
        st.download_button(
            label="📥 Download My Travel Guide",
            data=final,
            file_name=f"travel_guide_{destination.replace(' ', '_').replace(',', '')}.txt",
            mime="text/plain"
        )

    st.balloons()

# ── Empty state ──────────────────────────────
else:
    st.markdown("""
    <div style='text-align:center; padding:4rem 1rem; opacity:0.4;'>
        <div style='font-size:5rem'>🌍</div>
        <div style='font-size:1.3rem; margin-top:1rem;'>Enter a destination above to begin</div>
        <div style='font-size:0.85rem; margin-top:0.5rem;'>5 AI agents will collaborate to build your perfect travel guide</div>
    </div>
    """, unsafe_allow_html=True)