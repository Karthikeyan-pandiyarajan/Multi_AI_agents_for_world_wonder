# learning_example_2_translator.py — BUILD YOUR OWN: Simple Translator Agent

"""
═══════════════════════════════════════════════════════════════
   🎓 HANDS-ON EXAMPLE: Create a Translator Agent
═══════════════════════════════════════════════════════════════

This file shows you the COMPLETE process of:
1. Creating a custom agent from scratch
2. Using it with the LLM
3. Understanding how it works

This translator agent helps travelers by translating
important travel phrases into local languages.

Run this:
    python learning_example_2_translator.py

═══════════════════════════════════════════════════════════════
"""

from agents.base_agent import BaseAgent


class TranslatorAgent(BaseAgent):
    """
    📘 EXAMPLE: A Simple Translator Agent
    
    Notice:
    - It inherits from BaseAgent (gets .call() method for free)
    - __init__ defines its personality via system_instruction
    - run() is your custom method that uses self.call()
    - That's the all you need to create an AI agent!
    """

    def __init__(self):
        super().__init__(
            name="TranslatorAgent",
            emoji="🌍",
            role="Travel Phrase Translator",
            system_instruction=(
                "You are a friendly, multilingual travel guide. "
                "Translate travel phrases naturally and helpfully. "
                "Include pronunciation tips in parentheses. "
                "Be encouraging and make it fun!"
            )
        )

    def run(self, phrase: str, destination: str, language: str = None) -> str:
        """
        Translate a phrase for a specific destination.
        
        Args:
            phrase: English phrase to translate (e.g., "Where is the Eiffel Tower?")
            destination: Where they're traveling (e.g., "Paris")
            language: Optional language name (auto-detected from destination if None)
        
        Returns:
            Translated phrase with pronunciation
        """
        location_hint = f" (spoken in {language})" if language else ""
        
        prompt = f"""Translate this travel phrase for someone visiting {destination}{location_hint}:

English: "{phrase}"

Provide:
1. Local translation
2. Pronunciation (phonetic spelling)
3. One cultural tip about using this phrase

Keep it short and practical!"""

        return self.call(prompt)


def example_1_basic_translation():
    """Example 1: Simple translation"""
    print("\n" + "="*60)
    print("EXAMPLE 1: Basic Translation")
    print("="*60)

    translator = TranslatorAgent()
    
    result = translator.run(
        phrase="Where is the nearest restaurant?",
        destination="Paris",
        language="French"
    )
    
    print("\n📍 Destination: Paris")
    print("🗣️  English: Where is the nearest restaurant?")
    print("\n📝 Translation:")
    print(result)


def example_2_multiple_translations():
    """Example 2: Translate multiple phrases for same destination"""
    print("\n" + "="*60)
    print("EXAMPLE 2: Multiple Phrases for Different Destinations")
    print("="*60)

    translator = TranslatorAgent()
    
    phrases = [
        ("How much does this cost?", "Tokyo", "Japanese"),
        ("Can I have the bill please?", "Barcelona", "Spanish"),
        ("Excuse me, where is the bathroom?", "Rome", "Italian"),
    ]
    
    for phrase, destination, language in phrases:
        print(f"\n🌏 {destination} ({language})")
        print(f"   English: {phrase}")
        result = translator.run(phrase=phrase, destination=destination, language=language)
        print(f"   Translation:\n{result}\n")


def example_3_understand_the_flow():
    """Example 3: Understanding the complete flow"""
    print("\n" + "="*60)
    print("EXAMPLE 3: Understanding the Complete Flow")
    print("="*60)

    print("""
When you call: translator.run(phrase="Hello", destination="Tokyo")

Here's what happens BEHIND THE SCENES:

Step 1: Your code constructs a prompt
        └─ prompt = 'Translate "Hello" for someone visiting Tokyo'

Step 2: self.call(prompt) is invoked
        └─ This is defined in BaseAgent (parent class)
        └─ It sends an API request to Groq

Step 3: Groq receives TWO pieces of info:
        a) system_instruction (from __init__)
           └─ "You are a friendly multilingual travel guide..."
        b) prompt (from your run method)
           └─ "Translate 'Hello' for someone visiting Tokyo"

Step 4: Groq's Llama 3.3 model processes this and thinks:
        └─ "I'm a travel guide"
        └─ "I need to translate 'Hello' to Japanese"
        └─ "I should include pronunciation"
        └─ "I should be friendly"

Step 5: Llama generates a response:
        └─ "こんにちは (Kon'nichiha) - Hello
        └─  [pronunciation tips and cultural notes]"

Step 6: Response is returned to your code ✅

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

KEY INSIGHT:

You don't need to understand HOW Groq/Llama works internally.
You just need to understand:

1. WHO is the agent? (system_instruction)
   └─ Sets the LLM's role and personality

2. WHAT should it do? (prompt)
   └─ Your specific task or question

3. RESULT = LLM's response based on #1 + #2

That's the power of prompt engineering! 🚀
    """)


def example_4_modify_behavior():
    """Example 4: Changing system_instruction changes behavior"""
    print("\n" + "="*60)
    print("EXAMPLE 4: System Instructions Control LLM Behavior")
    print("="*60)

    print("""
Same phrase, different system instructions → different results:

┌─────────────────────────────────────────────────────────────┐
│ SCENARIO 1: Friendly Travel Guide                          │
│ system_instruction = "You are a friendly travel guide      │
│                       who makes translations fun"           │
│                                                              │
│ Result: Warm, encouraging, conversational response ✨       │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ SCENARIO 2: Professional Linguist                           │
│ system_instruction = "You are a professional linguist.     │
│                       Provide accurate, formal translations" │
│                                                              │
│ Result: Formal, precise, academic response 📚              │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ SCENARIO 3: Comedy Writer                                   │
│ system_instruction = "You are a funny travel comedian.     │
│                       Make translations hilarious!"         │
│                                                              │
│ Result: Funny, playful, witty response 😂                  │
└─────────────────────────────────────────────────────────────┘

SAME LLM MODEL (Llama 3.3)
SAME PROMPT ("Translate Hello")
DIFFERENT system_instruction
→ COMPLETELY DIFFERENT RESPONSES! 🎯

This is the POWER of prompt engineering.
You're using the same powerful LLM for different purposes.
    """)


def example_5_create_similar_agents():
    """Example 5: Ideas for creating similar agents"""
    print("\n" + "="*60)
    print("EXAMPLE 5: More Agent Ideas (Try Creating These!)")
    print("="*60)

    print("""
Now that you understand the pattern, here are agent ideas:

1️⃣  BUDGET CALCULATOR AGENT
    ├─ system_instruction: "You are a financial travel expert"
    ├─ run(destination, days, budget_category)
    ├─ Returns: Budget breakdown
    └─ Example: run("Tokyo", 7, "budget") → Cheap hotels, street food, etc.

2️⃣  PACKING LIST AGENT
    ├─ system_instruction: "You are a packing expert"
    ├─ run(destination, season, trip_type)
    ├─ Returns: Smart packing list
    └─ Example: run("Dubai", "summer", "beach") → Sun protection, light clothes, etc.

3️⃣  ITINERARY SUGGESTER AGENT
    ├─ system_instruction: "You are a creative travel planner"
    ├─ run(destination, days, interests)
    ├─ Returns: Day-by-day plan
    └─ Example: run("Paris", 3, ["art", "food"]) → Louvre, restaurants, etc.

4️⃣  PHOTO SPOT FINDER AGENT
    ├─ system_instruction: "You are a photography guide"
    ├─ run(destination, photography_style)
    ├─ Returns: Best photo locations
    └─ Example: run("Venice", "landscape") → Golden hour spots,canal views, etc.

5️⃣  WEATHER ADVISOR AGENT
    ├─ system_instruction: "You are a meteorologist travel guide"
    ├─ run(destination, month)
    ├─ Returns: Weather forecast + outfit advice
    └─ Example: run("Bangkok", "July") → Hot, humid, bring umbrella, etc.

6️⃣  CULTURAL ETIQUETTE AGENT
    ├─ system_instruction: "You are a cultural consultant"
    ├─ run(destination)
    ├─ Returns: Do's and don'ts
    └─ Example: run("Japan") → Remove shoes, don't tip, be quiet, etc.

7️⃣  EMERGENCY PHRASE AGENT
    ├─ system_instruction: "You are a safety advisor"
    ├─ run(emergency_type, destination)
    ├─ Returns: Emergency phrases + contact numbers
    └─ Example: run("medical", "India") → Hospital phrases,doctor contacts, etc.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

THE PATTERN IS ALWAYS THE SAME:

from agents.base_agent import BaseAgent

class YourNewAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="YourAgentName",
            emoji="✨",
            role="What it does",
            system_instruction="WHO you are as an AI"
        )
    
    def run(self, **kwargs):
        prompt = "Your custom task here"
        return self.call(prompt)

Then use it:
agent = YourNewAgent()
result = agent.run(param1="value1", param2="value2")

That's it! You can create unlimited AI agents now! 🚀
    """)


def main():
    print("""
╔══════════════════════════════════════════════════════════════╗
║  🎓 TRANSLATOR AGENT LEARNING EXAMPLE                       ║
║                                                              ║
║  This shows you how to:                                     ║
║  ✓ Create a custom agent                                   ║
║  ✓ Use the Groq LLM                                        ║
║  ✓ Control agent behavior                                  ║
║  ✓ Apply the same pattern to create any agent             ║
╚══════════════════════════════════════════════════════════════╝
    """)

    example_1_basic_translation()
    example_2_multiple_translations()
    example_3_understand_the_flow()
    example_4_modify_behavior()
    example_5_create_similar_agents()

    print("\n" + "="*60)
    print("✅ Learning Complete!")
    print("="*60)
    print("\n🎯 YOU NOW KNOW:")
    print("   ✓ How to inherit from BaseAgent")
    print("   ✓ How system_instruction shapes LLM behavior")
    print("   ✓ How to write effective prompts")
    print("   ✓ How to call the LLM via self.call()")
    print("   ✓ How to create unlimited custom agents")
    print("\n🚀 NEXT CHALLENGE:")
    print("   Try creating 'PackingListAgent' yourself!")
    print("   (Follow the same pattern as TranslatorAgent)")
    print("\n")


if __name__ == "__main__":
    main()
