# 📚 AGENTS AS TOOLS & SUBAGENTS - QUICK REFERENCE

## Files I Created

| File | Purpose |
|------|---------|
| `agents/weather_agent.py` | Example tool agent (weather info) |
| `agents/budget_agent.py` | Example tool agent (cost calculation) |
| `learning_example_3_agent_as_tools.py` | How to import & use agents as tools |
| `learning_example_4_tool_workflow.py` | Different architectural patterns |

---

## 🎯 THE 4 PATTERNS (Simplified)

### PATTERN 1️⃣: SIMPLE TOOLS
```python
# Just call agents like functions
from agents.weather_agent import WeatherAgent
from agents.budget_agent import BudgetAgent

weather = WeatherAgent()
budget = BudgetAgent()

w = weather.run("Paris")      # ← Call as tool
b = budget.run("Paris", 5)    # ← Call as tool

# Just combine results
results = {'weather': w, 'budget': b}
```

**When to use:** Simple, independent tasks

---

### PATTERN 2️⃣: ORCHESTRATOR + SUBAGENTS ⭐ (YOUR SYSTEM!)

```python
# One agent calls other agents (subagents)
from agents.base_agent import BaseAgent
from agents.weather_agent import WeatherAgent
from agents.budget_agent import BudgetAgent

class CoordinatorAgent(BaseAgent):
    def __init__(self):
        super().__init__(...)
        # ← Create subagents as attributes
        self.weather = WeatherAgent()
        self.budget = BudgetAgent()
    
    def run(self, destination, days):
        # ← Call subagents
        w = self.weather.run(destination)
        b = self.budget.run(destination, days)
        
        # ← LLM synthesizes intelligently
        prompt = f"Combine these reports: {w} + {b}"
        return self.call(prompt)  # ← Smart synthesis!
```

**When to use:** Need intelligent combining, hierarchical systems

**YOUR PROJECT USES THIS** ✨

---

### PATTERN 3️⃣: HIERARCHICAL AGENTS
```
Master Agent
  ├─ Team Lead 1 (coordinates group 1)
  │  ├─ Agent 1a
  │  ├─ Agent 1b
  │  └─ Agent 1c
  └─ Team Lead 2 (coordinates group 2)
     ├─ Agent 2a
     ├─ Agent 2b
     └─ Agent 2c
```

**When to use:** Large enterprise systems

---

### PATTERN 4️⃣: PIPE PATTERN
```
Input → Agent1 → Agent2 → Agent3 → Output
         (each uses previous output)
```

**When to use:** Sequential processing with dependencies

---

## 🔑 HOW TO IMPORT & USE AGENTS AS TOOLS

### Basic Import
```python
from agents.weather_agent import WeatherAgent
from agents.budget_agent import BudgetAgent
from agents.simple_quote_agent import SimpleQuoteAgent
```

### Use as Tools
```python
weather = WeatherAgent()
budget = BudgetAgent()
quote = SimpleQuoteAgent()

# Call them like functions
w = weather.run(destination="Tokyo", month="July")
b = budget.run(destination="Tokyo", days=5, budget_type="mid")
q = quote.run(topic="adventure")

# Use results
print(w)
print(b)
print(q)
```

### Use in Custom Agent (Subagent Pattern)
```python
class MasterAgent(BaseAgent):
    def __init__(self):
        super().__init__(...)
        # ← Store subagents
        self.weather = WeatherAgent()
        self.budget = BudgetAgent()
    
    def run(self, destination):
        # ← Call them
        w = self.weather.run(destination)
        b = self.budget.run(destination, 5)
        
        # ← Combine with LLM
        combined_prompt = f"""Create final guide:
        Weather: {w}
        Budget: {b}"""
        return self.call(combined_prompt)
```

---

## 🏗️ YOUR ACTUAL ARCHITECTURE

```
main.py / app.py
    ↓
Imports: [WonderScout, Itinerary, Culture, Safety, MasterConcierge]
    ↓
Creates instances (they are TOOLS):
    scout = WonderScoutAgent()
    itinerary = ItineraryArchitectAgent()
    culture = CultureChefAgent()
    safety = SafetyGuardianAgent()
    ↓
Calls first 4 as TOOLS:
    scout_report = scout.run(destination)
    itinerary_report = itinerary.run(destination, days)
    culture_report = culture.run(destination)
    safety_report = safety.run(destination)
    ↓
Creates ORCHESTRATOR:
    concierge = MasterConciergeAgent()
    ↓
Pass all 4 reports as SUBAGENT outputs:
    final = concierge.run(
        destination,
        days,
        all_reports={...}  ← Subagent reports
    )
    ↓
MasterConcierge synthesizes with LLM ✨
```

**This uses PATTERN 2 (Orchestrator + Subagents)** - Best of both worlds!

---

## 📖 WHAT THE TUTORIALS MEAN

When you see:
- **"Import agents"** → `from agents.x import XAgent`
- **"Use agents as tools"** → `agent.run()` (call like functions)
- **"Subagents"** → One agent calls other agents
- **"Tools"** → Reusable agents you call from other code
- **"Agents"** → Intelligent systems with LLM (your agents)

---

## 🚀 Key Differences

| Concept | What it means |
|---------|---------------|
| **Import Agent** | Get a class with `from agents.x import X` |
| **Create Instance** | `agent = XAgent()` |
| **Use as Tool** | `result = agent.run(params)` |
| **Subagent** | One agent created INSIDE another agent |
| **Tool** | Any agent you call from external code |
| **Orchestrator** | Agent that calls other agents |
| **Synthesis** | Combining outputs (usually with LLM) |

---

## ✅ YOUR NEXT CHALLENGE

Create a new agent that:
1. **Imports** WeatherAgent + BudgetAgent as subagents
2. **Calls** both in its `run()` method
3. **Combines** results with LLM prompt
4. **Returns** synthesized travel advice

**Template:**
```python
from .base_agent import BaseAgent
from .weather_agent import WeatherAgent
from .budget_agent import BudgetAgent

class SmartPlannerAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="SmartPlanner",
            emoji="🎯",
            role="Smart Travel Planner",
            system_instruction="You plan perfect trips by combining weather and budget data"
        )
        self.weather = WeatherAgent()  # ← Subagent
        self.budget = BudgetAgent()    # ← Subagent
    
    def run(self, destination, days):
        # Call subagents
        w = self.weather.run(destination)
        b = self.budget.run(destination, days)
        
        # Synthesize with LLM
        prompt = f"Create smart plan combining: {w} + {b}"
        return self.call(prompt)
```

Then use it:
```python
planner = SmartPlannerAgent()
plan = planner.run("Amsterdam", 3)
print(plan)
```

---

## 📚 Learning Files to Run

```bash
# Learn basic tools pattern
python learning_example_3_agent_as_tools.py

# Learn all 4 patterns
python learning_example_4_tool_workflow.py

# Run your actual system
python main.py
```

---

Good luck! You now understand how tutorials use "agents as tools" and "subagents"! 🎉
