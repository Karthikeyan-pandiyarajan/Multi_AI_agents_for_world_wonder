# ─────────────────────────────────────────
#   config/settings.py — App Configuration
# ─────────────────────────────────────────

import os
from groq import Groq
from dotenv import load_dotenv

# Load .env file
load_dotenv()

# Groq API Key
GROQ_API_KEY = os.getenv("GROQ_API_KEY")

# Model — free & very fast ✅
GROQ_MODEL = "llama-3.3-70b-versatile"

def init_groq() -> Groq:
    """Initialize and return Groq client."""
    if not GROQ_API_KEY:
        raise ValueError("❌ GROQ_API_KEY not found! Check your .env file.")
    print(f"✅ Groq initialized — model: {GROQ_MODEL}")
    return Groq(api_key=GROQ_API_KEY)