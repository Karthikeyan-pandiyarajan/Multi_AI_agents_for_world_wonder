# agents/master_concierge.py — Agent 5: MasterConciergeAgent (Orchestrator)

from .base_agent import BaseAgent


class MasterConciergeAgent(BaseAgent):
    """
    Agent 5 — MasterConciergeAgent (Orchestrator)
    Receives all 4 specialist reports and synthesizes
    them into one beautiful final travel guide.
    """

    def __init__(self):
        super().__init__(
            name="MasterConciergeAgent",
            emoji="✨",
            role="Final Guide Synthesis",
            system_instruction=(
                "You are the MasterConcierge, a legendary luxury travel advisor "
                "who has visited every wonder of the world. You synthesize your "
                "specialist team reports into one cohesive, beautiful, personal "
                "travel guide. Write like a warm letter to a dear friend."
            )
        )

    def run(self, destination: str, days: int, all_reports: dict) -> str:
        combined = "\n\n".join([
            f"=== {name} ===\n{report}"
            for name, report in all_reports.items()
        ])

        prompt = f"""Create the ULTIMATE {days}-Day Travel Guide for: {destination}

        Your specialist team reports:
        {combined}

        Synthesize into one beautiful guide with these sections:
        ✈️  Opening  — paint a vivid picture of why this wonder changes lives
        🗺️  Journey  — weave itinerary highlights with cultural insights
        🍽️  Culture  — top food and cultural experiences
        ⚠️  Smart    — key safety tips, brief and reassuring
        💡  Pro Tips — 3 insider secrets only true experts know
        🌟  Closing  — inspiring call to action that makes them book NOW

        Make it feel like a personal letter from a wise well-traveled friend."""

        return self.call(prompt)