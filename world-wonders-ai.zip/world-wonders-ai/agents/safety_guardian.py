# agents/safety_guardian.py — Agent 4: SafetyGuardianAgent

from .base_agent import BaseAgent


class SafetyGuardianAgent(BaseAgent):
    """
    Agent 4 — SafetyGuardianAgent
    Covers visa, health, scams, packing
    and essential apps for safe travel.
    """

    def __init__(self):
        super().__init__(
            name="SafetyGuardianAgent",
            emoji="⚠️",
            role="Safety & Practical Tips",
            system_instruction=(
                "You are SafetyGuardian, a seasoned travel risk consultant. "
                "You provide practical, non-scary safety advice. "
                "Tone: calm, reassuring and empowering. "
                "Travel is always worth it — just be prepared!"
            )
        )

    def run(self, destination: str) -> str:
        prompt = f"""Create a safety and practical guide for: {destination}

        Include:
        1. 🛂 Visa and entry requirements overview
        2. 💉 Health precautions and recommended vaccinations
        3. 🦹 Top 3 tourist scams and how to avoid them
        4. 🎒 Essential packing list specific to this destination
        5. 📱 Must-have apps for this destination"""

        return self.call(prompt)