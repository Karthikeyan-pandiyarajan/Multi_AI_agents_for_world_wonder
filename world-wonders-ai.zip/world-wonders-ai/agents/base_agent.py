# ──────────────────────────────────────────────────────
#   agents/base_agent.py — Base Agent (Groq powered)
# ──────────────────────────────────────────────────────

import os
import time
from groq import Groq
from dotenv import load_dotenv

load_dotenv()

# Shared Groq client used by ALL agents
_client = Groq(api_key=os.getenv("GROQ_API_KEY"))
GROQ_MODEL = "llama-3.3-70b-versatile"


class BaseAgent:
    """
    Base class for all AI agents.
    Uses Groq (FREE) instead of Gemini.
    Every agent inherits this and defines its own
    system_instruction and run() method.
    """

    def __init__(self, name: str, emoji: str, role: str, system_instruction: str):
        self.name               = name
        self.emoji              = emoji
        self.role               = role
        self.system_instruction = system_instruction

    def call(self, prompt: str) -> str:
        """Send prompt to Groq LLM and return text response."""
        print(f"\n⏳ {self.emoji} [{self.name}] is working...")

        response = _client.chat.completions.create(
            model=GROQ_MODEL,
            messages=[
                {"role": "system", "content": self.system_instruction},
                {"role": "user",   "content": prompt}
            ],
            temperature=0.7,
            max_tokens=1024,
        )

        result = response.choices[0].message.content
        print(f"✅ [{self.name}] Done!")
        time.sleep(1)  # small pause between agents
        return result

    def run(self, **kwargs) -> str:
        """Override in each agent subclass."""
        raise NotImplementedError("Each agent must implement run()")