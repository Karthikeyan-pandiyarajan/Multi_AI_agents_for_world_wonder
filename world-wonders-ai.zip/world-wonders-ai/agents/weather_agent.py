# agents/weather_agent.py — Example: A Tool-Like Agent

from .base_agent import BaseAgent


class WeatherAgent(BaseAgent):
    """
    🌤️ TOOL AGENT EXAMPLE
    
    This agent can be used as a "tool" that other agents call.
    It specializes in weather recommendations for travel.
    """

    def __init__(self):
        super().__init__(
            name="WeatherAgent",
            emoji="🌤️",
            role="Weather & Climate Expert",
            system_instruction=(
                "You are a travel meteorologist. "
                "Provide weather forecasts and what to pack. "
                "Be practical and helpful."
            )
        )

    def run(self, destination: str, month: str = None) -> str:
        """Get weather info for a destination."""
        month_info = f" in {month}" if month else ""
        prompt = f"What's the weather like in {destination}{month_info}? Include packing tips."
        return self.call(prompt)
