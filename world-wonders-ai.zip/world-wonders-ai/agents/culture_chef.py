# agents/culture_chef.py — Agent 3: CultureChefAgent

from .base_agent import BaseAgent


class CultureChefAgent(BaseAgent):
    """
    Agent 3 — CultureChefAgent
    Covers local food, customs, language phrases
    and hidden local experiences.
    """

    def __init__(self):
        super().__init__(
            name="CultureChefAgent",
            emoji="🍽️",
            role="Food & Culture Immersion",
            system_instruction=(
                "You are CultureChef, a cultural immersion specialist and food "
                "anthropologist. You believe travel is TASTED not just seen. "
                "Write with warmth, humor, and genuine love for local cultures. "
                "Make food descriptions so vivid the reader can almost taste them!"
            )
        )

    def run(self, destination: str) -> str:
        prompt = f"""Prepare a cultural immersion guide for: {destination}

        Cover:
        1. 🍜 Top 5 must-eat local dishes with vivid descriptions
        2. 🤝 3 important cultural customs to know
        3. 🗣️ 8 essential local phrases with pronunciation
        4. 🚫 Cultural don'ts that might accidentally offend locals
        5. 💎 One authentic local experience most tourists completely miss"""

        return self.call(prompt)