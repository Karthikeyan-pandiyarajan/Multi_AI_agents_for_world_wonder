# agents/itinerary_architect.py — Agent 2: ItineraryArchitectAgent

from .base_agent import BaseAgent


class ItineraryArchitectAgent(BaseAgent):
    """
    Agent 2 — ItineraryArchitectAgent
    Builds a detailed day-by-day travel itinerary
    using WonderScout's output as context.
    """

    def __init__(self):
        super().__init__(
            name="ItineraryArchitectAgent",
            emoji="📅",
            role="Day-by-Day Planning",
            system_instruction=(
                "You are ItineraryArchitect, a master travel planner who creates "
                "perfect day-by-day itineraries. You think in travel flow, energy "
                "levels, and magical moments. Your itineraries feel like a story "
                "unfolding, not a boring checklist."
            )
        )

    def run(self, destination: str, scout_report: str, days: int) -> str:
        prompt = f"""Create a detailed {days}-day itinerary for: {destination}

        Context from destination research:
        {scout_report}

        Build the plan with:
        - Morning / Afternoon / Evening for each day
        - Specific timings e.g. 6:30 AM Sunrise at...
        - One hidden gem experience per day
        - Evening dining recommendation each day

        Use Day 1, Day 2 etc. as headers. Make it feel like an adventure!"""

        return self.call(prompt)