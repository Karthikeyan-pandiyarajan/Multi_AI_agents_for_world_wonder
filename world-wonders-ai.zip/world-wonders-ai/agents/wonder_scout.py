# agents/wonder_scout.py — Agent 1: WonderScoutAgent

from .base_agent import BaseAgent


class WonderScoutAgent(BaseAgent):
    """
    Agent 1 — WonderScoutAgent
    Researches the destination: history, best time,
    top spots, budget and difficulty.
    """

    def __init__(self):
        super().__init__(
            name="WonderScoutAgent",
            emoji="🔍",
            role="Destination Intelligence",
            system_instruction=(
                "You are WonderScout, an elite UNESCO World Heritage expert "
                "with 30 years of travel experience. You know every wonder of "
                "the world — ancient, modern, natural, and hidden gems. "
                "Write with passion and excitement to inspire the reader!"
            )
        )

    def run(self, destination: str) -> str:
        prompt = f"""The traveler wants to visit: {destination}

        Provide a rich destination briefing:
        1. 🏛️ 3 surprising historical facts
        2. 📅 Best months to visit and why
        3. 📍 Top 5 must-see spots or experiences
        4. 💰 Budget overview (budget / mid / luxury daily cost)
        5. 🎯 Difficulty and accessibility rating

        Keep it exciting and informative!"""

        return self.call(prompt)