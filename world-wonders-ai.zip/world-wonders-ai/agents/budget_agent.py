# agents/budget_agent.py — Example: Another Tool-Like Agent

from .base_agent import BaseAgent


class BudgetAgent(BaseAgent):
    """
    💰 TOOL AGENT EXAMPLE
    
    Estimates travel costs. Can be called by other agents.
    """

    def __init__(self):
        super().__init__(
            name="BudgetAgent",
            emoji="💰",
            role="Travel Budget Calculator",
            system_instruction=(
                "You are a travel finance expert. "
                "Provide realistic budget estimates. "
                "Break down costs by category."
            )
        )

    def run(self, destination: str, days: int, budget_type: str = "mid") -> str:
        """Calculate budget for a trip."""
        prompt = f"""Estimate {budget_type} budget for {days} days in {destination}.
        Include: accommodation, food, transport, attractions."""
        return self.call(prompt)
