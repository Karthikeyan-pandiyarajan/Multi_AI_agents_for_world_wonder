# agents/simple_quote_agent.py — LEARNING EXAMPLE: Simple Custom Agent

from .base_agent import BaseAgent


class SimpleQuoteAgent(BaseAgent):
    """
    ✏️ LEARNING EXAMPLE
    
    A simple custom agent that generates inspirational quotes.
    This shows the BASIC PATTERN for creating any custom agent:
    
    1. Inherit from BaseAgent
    2. Set name, emoji, role, system_instruction in __init__
    3. Implement run() method with your custom prompt
    4. Call self.call(prompt) to invoke the LLM
    
    That's it! You can now use Groq LLM for anything.
    """

    def __init__(self):
        # ← This is where you define the agent's personality
        super().__init__(
            name="SimpleQuoteAgent",
            emoji="💡",
            role="Inspirational Quote Generator",
            system_instruction=(
                "You are a wise travel philosopher. "
                "Generate short, inspiring travel quotes that motivate people. "
                "Keep quotes under 20 words. Be poetic and uplifting."
            )
        )

    def run(self, topic: str = "adventure") -> str:
        """
        Generate a quote about the given topic.
        
        Args:
            topic: What the quote should be about (e.g., "adventure", "courage", "discovery")
        
        Returns:
            A single inspirational travel quote
        """
        # ← This is the prompt you send to the LLM
        prompt = f"Generate one inspirational travel quote about {topic}."

        # ← This calls Groq LLM with your system_instruction + prompt
        return self.call(prompt)
