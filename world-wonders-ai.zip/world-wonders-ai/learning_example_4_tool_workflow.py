# learning_example_4_tool_workflow.py
"""
═══════════════════════════════════════════════════════════════
   🎓 HOW OTHER TUTORIALS STRUCTURE TOOLS & AGENTS
═══════════════════════════════════════════════════════════════

This shows you DIFFERENT ways to structure agent systems:

1. TOOL PATTERN: Agents as reusable utilities
2. AGENT PATTERN: Independent intelligent agents
3. ORCHESTRATOR PATTERN: Master agent coordinating
4. FRAMEWORK PATTERN: Like MCP servers or hierarchical agents

Run this:
    python learning_example_4_tool_workflow.py

═══════════════════════════════════════════════════════════════
"""


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# TUTORIAL PATTERN #1: AGENTS AS TOOLS (WHAT OTHER TUTORIALS DO)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def pattern_1_agents_as_tools():
    """
    PATTERN 1: Simple tool pattern (very common in tutorials)
    
    Structure:
        ├─ tools.py or agent_tools.py
        │  ├─ SearchTool (Agent 1)
        │  ├─ AnalyzeTool (Agent 2)
        │  ├─ SummarizeTool (Agent 3)
        │  └─ [Each is a simple agent]
        │
        ├─ main.py
        │  └─ Imports all tools
        │  └─ Uses them sequentially
        │  └─ Collects results
        │  └─ Returns combined output
    """
    print("\n" + "="*60)
    print("PATTERN 1: Agents as Tools")
    print("="*60)

    print("""
📦 STRUCTURE:

    from agents.weather_agent import WeatherAgent
    from agents.budget_agent import BudgetAgent
    from agents.safety_agent import SafetyAgent
    
    def plan_trip(destination, days):
        # Get weather info (Tool 1)
        weather_result = WeatherAgent().run(destination)
        
        # Get budget (Tool 2)
        budget_result = BudgetAgent().run(destination, days)
        
        # Get safety info (Tool 3)
        safety_result = SafetyAgent().run(destination)
        
        # Combine them
        return {
            'weather': weather_result,
            'budget': budget_result,
            'safety': safety_result
        }
    
    # Use it
    trip = plan_trip('Paris', 5)
    print(trip['weather'])
    print(trip['budget'])
    print(trip['safety'])

✅ WHEN TO USE:
   - Simple sequential tasks
   - Independent tools
   - Each agent has one job
   - No communication between agents

❌ LIMITATIONS:
   - No intelligence in combining
   - No context passing
   - Results are just concatenated
   - No synthesis or refinement
    """)

    from agents.weather_agent import WeatherAgent
    from agents.budget_agent import BudgetAgent

    # Simple tool pattern
    print("\n🔨 Testing Tool Pattern:\n")

    weather = WeatherAgent()
    budget = BudgetAgent()

    w_result = weather.run("Seoul", "March")
    b_result = budget.run("Seoul", 4)

    trip_info = {
        'destination': 'Seoul',
        'days': 4,
        'weather': w_result,
        'budget': b_result
    }

    print(f"Trip to {trip_info['destination']} ({trip_info['days']} days)")
    print(f"\n🌤️ Weather:\n{trip_info['weather'][:200]}...")
    print(f"\n💰 Budget:\n{trip_info['budget'][:200]}...")


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# TUTORIAL PATTERN #2: ORCHESTRATOR WITH SUBAGENTS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def pattern_2_orchestrator_subagents():
    """
    PATTERN 2: Master orchestrator with intelligent subagents
    
    Structure:
        ├─ agents/
        │  ├─ base_agent.py (parent class)
        │  ├─ weather_agent.py (Tool 1)
        │  ├─ budget_agent.py (Tool 2)
        │  ├─ safety_agent.py (Tool 3)
        │  └─ coordinator_agent.py (Master - calls subagents)
        │
        └─ main.py
           └─ Creates coordinator
           └─ Coordinator calls all subagents
           └─ Coordinator synthesizes results with LLM
    """
    print("\n" + "="*60)
    print("PATTERN 2: Orchestrator with Subagents (YOUR SYSTEM!)")
    print("="*60)

    print("""
🎭 STRUCTURE:

    from agents.base_agent import BaseAgent
    from agents.weather_agent import WeatherAgent
    from agents.budget_agent import BudgetAgent
    
    class MasterAgent(BaseAgent):
        def __init__(self):
            super().__init__(...)
            # ← Create subagents as attributes
            self.weather = WeatherAgent()
            self.budget = BudgetAgent()
        
        def run(self, destination, days):
            # ← Call subagents
            w = self.weather.run(destination)
            b = self.budget.run(destination, days)
            
            # ← Combine + send to LLM (intelligent synthesis)
            prompt = f"Synthesize: {w} + {b} into travel guide"
            return self.call(prompt)  # ← LLM combines intelligently
    
    # Use it
    master = MasterAgent()
    guide = master.run('Paris', 5)  # ← Gets intelligent synthesis
    print(guide)

✅ WHEN TO USE:
   - Complex coordination needed
   - Subagents depend on each other
   - Need intelligent synthesis
   - Building hierarchical systems

✅ ADVANTAGES:
   ✓ Intelligent combination (LLM synthesis)
   ✓ Agents communicate with each other
   ✓ Scalable architecture
   ✓ Each agent is reusable
   ✓ Easy to add new subagents
   
⭐ THIS IS WHAT YOUR PROJECT USES!
    """)

    from agents.base_agent import BaseAgent
    from agents.weather_agent import WeatherAgent
    from agents.budget_agent import BudgetAgent

    class SmartMasterAgent(BaseAgent):
        def __init__(self):
            super().__init__(
                name="SmartMaster",
                emoji="🧠",
                role="Intelligent Coordinator",
                system_instruction=(
                    "You are a master travel planner. "
                    "Synthesize expert reports into brilliant travel advice."
                )
            )
            self.weather = WeatherAgent()
            self.budget = BudgetAgent()

        def run(self, destination: str, days: int) -> str:
            # Get subagent outputs
            weather = self.weather.run(destination)
            budget = self.budget.run(destination, days)

            # Intelligent synthesis
            prompt = f"""Create a smart travel plan:
            
Weather insights:
{weather}

Budget constraints:
{budget}

Synthesize both into ONE cohesive travel strategy. 
Include: best time to visit, smart budgeting tips, what to pack."""

            return self.call(prompt)

    print("\n🧠 Testing Orchestrator Pattern:\n")

    master = SmartMasterAgent()
    result = master.run("Amsterdam", 3)

    print("📋 Intelligently synthesized travel plan:")
    print(result[:400] + "...")


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# TUTORIAL PATTERN #3: HIERARCHICAL AGENTS (Advanced)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def pattern_3_hierarchical_agents():
    """
    PATTERN 3: Hierarchical agents (like MCP servers)
    
    Structure:
        Level 1 (User)
           ↓
        Level 2 (Master Agent) - Makes decisions
           ├─ Level 3 (Team Lead 1) - Coordinates group
           │  ├─ Agent 1a
           │  ├─ Agent 1b
           │  └─ Agent 1c
           └─ Level 3 (Team Lead 2) - Coordinates group
              ├─ Agent 2a
              ├─ Agent 2b
              └─ Agent 2c
    """
    print("\n" + "="*60)
    print("PATTERN 3: Hierarchical Agents (Advanced)")
    print("="*60)

    print("""
🏢 STRUCTURE (Multi-level hierarchy):

    Level 1: MasterCoordinator
             ├─ Calls TeamLead_Logistics
             │  ├─ Has: TransportAgent, HotelAgent, CarRentalAgent
             │  └─ Returns: Complete logistics plan
             │
             └─ Calls TeamLead_Experience
                ├─ Has: CultureAgent, FoodAgent, AdventureAgent
                └─ Returns: Experience recommendations

    CODE EXAMPLE:
    
    class MasterCoordinator(BaseAgent):
        def run(self, destination):
            # ← Call team leads (not individual agents)
            logistics = self.logistics_team.run(destination)
            experience = self.experience_team.run(destination)
            
            # ← Synthesize
            return self.call(f"Combine: {logistics} + {experience}")
    
    class LogisticsTeam(BaseAgent):
        def __init__(self):
            self.transport = TransportAgent()
            self.hotel = HotelAgent()
        
        def run(self, destination):
            t = self.transport.run(destination)
            h = self.hotel.run(destination)
            # ← This team also synthesizes
            return self.call(f"Plan logistics: {t} + {h}")

✅ WHEN TO USE:
   - Large systems with many agents
   - Need organizational structure
   - Agents have different domains/levels
   - Building AI franchises or platforms

✅ LIKE:
   - MCP (Model Context Protocol) servers
   - Anthropic Claude multi-agent examples
   - Enterprise AI systems
    """)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# TUTORIAL PATTERN #4: PIPE PATTERN (Stream Processing)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def pattern_4_pipe_pattern():
    """
    PATTERN 4: Pipe/Stream pattern (LangChain style)
    
    Agent A → Output A
      ↓
    Agent B (uses Output A) → Output B
      ↓
    Agent C (uses Output B) → Output C
      ↓
    Final Result
    """
    print("\n" + "="*60)
    print("PATTERN 4: Pipe Pattern (LangChain Style)")
    print("="*60)

    print("""
⛓️  STRUCTURE (Sequential piping):

    Input
      ↓
    Agent1: Extract Info
      ↓
    Agent2: Analyze (uses Agent1 output)
      ↓
    Agent3: Synthesize (uses Agent2 output)
      ↓
    Final Output

    CODE EXAMPLE:
    
    def pipeline(destination):
        # Step 1: Collect info
        collector = InfoCollectorAgent()
        info = collector.run(destination)
        
        # Step 2: Analyze (USES previous output)
        analyzer = AnalyzerAgent()
        analysis = analyzer.run(destination, context=info)
        
        # Step 3: Create plan (USES previous output)
        planner = PlannerAgent()
        plan = planner.run(destination, context=analysis)
        
        return plan

This is like:
    input | agent1 | agent2 | agent3 > output

✅ WHEN TO USE:
   - Sequential processing
   - Each step depends on previous
   - Data transformation pipelines
   - LangChain-style chains

⚠️ vs YOUR SYSTEM:
   Your system is NOT pipe pattern.
   Your agents run INDEPENDENTLY (not dependent on each other).
   They all get processed at once, then combined.
    """)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# COMPARISON TABLE
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def comparison_patterns():
    """Compare all patterns"""
    print("\n" + "="*60)
    print("COMPARISON: Which Pattern to Use?")
    print("="*60)

    print("""
PATTERN #1: Simple Tools
├─ Complexity: ⭐ (Simple)
├─ When: Simple tasks, independent agents
├─ Pros: Easy to understand, minimal code
├─ Cons: No intelligent combining
├─ Example: Just calling agents in sequence
└─ Code complexity: Low

PATTERN #2: Orchestrator + Subagents ⭐⭐⭐ (RECOMMENDED)
├─ Complexity: ⭐⭐ (Medium)
├─ When: Need intelligent coordination
├─ Pros: Scalable, LLM synthesis, clean structure
├─ Cons: Need to design agent hierarchy
├─ Example: YOUR CURRENT SYSTEM!
└─ Code complexity: Medium

PATTERN #3: Hierarchical Agents
├─ Complexity: ⭐⭐⭐ (Complex)
├─ When: Large enterprise systems
├─ Pros: Organizational clarity, scalable
├─ Cons: Overhead for small projects
├─ Example: AI franchises, MCP servers
└─ Code complexity: High

PATTERN #4: Pipe Pattern
├─ Complexity: ⭐⭐ (Medium)
├─ When: Sequential data processing
├─ Pros: Each step transparent
├─ Cons: Not good for independent tasks
├─ Example: LangChain chains
└─ Code complexity: Medium

═════════════════════════════════════════════════════════════════

YOUR CHOICE: Use Pattern #2 (Orchestrator + Subagents)

Why?
✓ Perfect balance of simplicity & power
✓ Agents are reusable
✓ Intelligent synthesis via LLM
✓ Easy to add new agents
✓ Professional architecture
✓ Scales from small to large

This is what:
✓ Your MasterConcierge does
✓ Most AI tutorials recommend
✓ Production systems use
    """)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# How to Add Agents as Tools
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def how_to_import_and_use():
    """Show exact import and usage patterns"""
    print("\n" + "="*60)
    print("HOW TO: Import & Use Agents as Tools")
    print("="*60)

    print("""
BASIC IMPORT & USE:

    # ← Step 1: Import the agent
    from agents.weather_agent import WeatherAgent
    
    # ← Step 2: Create instance
    weather = WeatherAgent()
    
    # ← Step 3: Use it (call the run method)
    result = weather.run(destination="Tokyo")
    
    # ← Step 4: Get result
    print(result)

═════════════════════════════════════════════════════════════════

MULTIPLE IMPORTS:

    from agents.weather_agent import WeatherAgent
    from agents.budget_agent import BudgetAgent
    from agents.simple_quote_agent import SimpleQuoteAgent
    
    # Create all at once
    weather = WeatherAgent()
    budget = BudgetAgent()
    quote = SimpleQuoteAgent()
    
    # Call them as tools
    w = weather.run("Paris")
    b = budget.run("Paris", 5)
    q = quote.run("adventure")

═════════════════════════════════════════════════════════════════

USING IN A CUSTOM AGENT (Subagent pattern):

    from .base_agent import BaseAgent
    from .weather_agent import WeatherAgent
    from .budget_agent import BudgetAgent
    
    class MyCoordinator(BaseAgent):
        def __init__(self):
            super().__init__(...)
            # ← Store agents as attributes
            self.weather = WeatherAgent()
            self.budget = BudgetAgent()
        
        def run(self, destination):
            # ← Call them
            w = self.weather.run(destination)
            b = self.budget.run(destination, 5)
            
            # ← Use their outputs
            prompt = f"Combine: {w} + {b}"
            return self.call(prompt)

═════════════════════════════════════════════════════════════════

USING IN MAIN SCRIPT:

    # main.py
    
    from agents.weather_agent import WeatherAgent
    from agents.master_concierge import MasterConciergeAgent
    
    # Get info from tool
    weather = WeatherAgent()
    weather_info = weather.run("Barcelona")
    
    # Use it in orchestrator
    concierge = MasterConciergeAgent()
    final = concierge.run(
        destination="Barcelona",
        days=4,
        weather_context=weather_info
    )

═════════════════════════════════════════════════════════════════

THIS IS HOW YOUR ACTUAL main.py WORKS:

    from agents import (
        WonderScoutAgent,      # ← Import
        ItineraryArchitectAgent,
        CultureChefAgent,
        SafetyGuardianAgent,
        MasterConciergeAgent,
    )
    
    # Create instances (they are your "tools")
    scout = WonderScoutAgent()
    itinerary = ItineraryArchitectAgent()
    culture = CultureChefAgent()
    safety = SafetyGuardianAgent()
    concierge = MasterConciergeAgent()
    
    # Use first 4 as tools
    scout_report = scout.run(destination)
    itinerary_report = itinerary.run(destination, days)
    culture_report = culture.run(destination)
    safety_report = safety.run(destination)
    
    # Use master to synthesize
    final = concierge.run(
        destination,
        days,
        all_reports={
            "WonderScout": scout_report,
            "Itinerary": itinerary_report,
            "Culture": culture_report,
            "Safety": safety_report,
        }
    )
    """)


def main():
    print("""
╔══════════════════════════════════════════════════════════════╗
║  🎓 TOOLS, AGENTS & PATTERNS IN OTHER TUTORIALS             ║
║                                                              ║
║  Learn:                                                      ║
║  ✓ How other tutorials structure agents                     ║
║  ✓ Different architectural patterns                          ║
║  ✓ Tools vs Agents vs Subagents                             ║
║  ✓ How to import and use agents                             ║
║  ✓ Comparison of patterns                                   ║
║  ✓ Best practices                                           ║
╚══════════════════════════════════════════════════════════════╝
    """)

    pattern_1_agents_as_tools()
    pattern_2_orchestrator_subagents()
    pattern_3_hierarchical_agents()
    pattern_4_pipe_pattern()
    comparison_patterns()
    how_to_import_and_use()

    print("\n" + "="*60)
    print("✅ Pattern Learning Complete!")
    print("="*60)
    print("""
🎯 KEY TAKEAWAYS:

1️⃣  AGENTS ARE TOOLS
   └─ Import them
   └─ Call their run() method
   └─ Get results
   └─ Simple as functions

2️⃣  PATTERNS MATTER
   └─ Simple tools: Just call them
   └─ Orchestrator: One master calls subagents ⭐
   └─ Hierarchical: Teams of teams
   └─ Pipe: Sequential processing

3️⃣  YOUR SYSTEM USES PATTERN #2 ✨
   └─ 4 specialist agents (Weather, Budget, etc.)
   └─ 1 master orchestrator (MasterConcierge)
   └─ Intelligent synthesis with LLM
   └─ Professional architecture

4️⃣  HOW TO IMPORT & USE
   └─ from agents.agent_name import AgentClass
   └─ agent = AgentClass()
   └─ result = agent.run(params)
   └─ Use result in your code

🚀 NEXT CHALLENGE:

   Create a new coordinator agent that:
   ├─ Imports WeatherAgent + BudgetAgent
   ├─ Calls both agents
   ├─ Combines results with LLM
   ├─ Returns intelligent synthesis

Good luck! 🎉
    """)


if __name__ == "__main__":
    main()
