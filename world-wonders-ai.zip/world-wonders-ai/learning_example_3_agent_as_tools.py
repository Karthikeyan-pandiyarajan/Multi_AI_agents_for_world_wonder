# learning_example_3_agent_as_tools.py
"""
═══════════════════════════════════════════════════════════════
   🎓 AGENTS AS TOOLS: Import & Use Agents As Functions
═══════════════════════════════════════════════════════════════

This teaches you:
1. How to IMPORT agents
2. How to USE agents as "tools" (call them from other code)
3. How agents can be COMBINED together
4. Composition vs Inheritance patterns

Run this:
    python learning_example_3_agent_as_tools.py

═══════════════════════════════════════════════════════════════
"""


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# PART 1: Import agents as tools
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

from agents.weather_agent import WeatherAgent
from agents.budget_agent import BudgetAgent
from agents.simple_quote_agent import SimpleQuoteAgent


def example_1_single_agent_as_tool():
    """EXAMPLE 1: Use a single agent as a tool"""
    print("\n" + "="*60)
    print("EXAMPLE 1: Single Agent as a Tool")
    print("="*60)

    # ← Import agent
    weather = WeatherAgent()

    # ← Use it like a tool (call it as a function)
    print("\n🌤️ Getting weather information...")
    result = weather.run(destination="Tokyo", month="July")
    
    print("\n📍 Destination: Tokyo (July)")
    print("📝 Weather Info:")
    print(result)


def example_2_multiple_agents_as_tools():
    """EXAMPLE 2: Use multiple agents together (COMPOSITION)"""
    print("\n" + "="*60)
    print("EXAMPLE 2: Multiple Agents as Tools (Composition)")
    print("="*60)

    print("""
🔌 COMPOSITION PATTERN:
   ├─ You orchestrate multiple agents
   ├─ Collect their outputs
   ├─ Combine them into one result
   └─ This is what your MasterConcierge does!

┌─────────────────────────────────────────┐
│ Your Main Code                          │
│ (Orchestrator)                          │
│                                         │
│  1. Call WeatherAgent                  │ ← Tool #1
│  2. Call BudgetAgent                   │ ← Tool #2
│  3. Call SimpleQuoteAgent              │ ← Tool #3
│  4. Combine all outputs                │
│                                         │
└─────────────────────────────────────────┘
    """)

    # Create agent instances
    weather = WeatherAgent()
    budget = BudgetAgent()
    quote = SimpleQuoteAgent()

    destination = "Paris"
    days = 5

    print(f"\n📍 Plan {days} days in {destination}\n")

    # Call each agent as a tool
    print("⏳ Gathering information from all tools...\n")
    
    weather_info = weather.run(destination=destination, month="September")
    print(f"✅ Weather info gathered")
    
    budget_info = budget.run(destination=destination, days=days, budget_type="mid")
    print(f"✅ Budget calculated")
    
    inspiration = quote.run(topic="adventure")
    print(f"✅ Inspiration quote ready")

    # Combine results
    print("\n" + "="*60)
    print(f"📋 COMBINED TRIP PLAN FOR {destination}")
    print("="*60)
    print(f"\n💭 Inspiration:\n{inspiration}")
    print(f"\n🌤️ Weather:\n{weather_info}")
    print(f"\n💰 Budget:\n{budget_info}")


def example_3_agent_calling_agents():
    """EXAMPLE 3: Agent that calls other agents (SUBAGENTS)"""
    print("\n" + "="*60)
    print("EXAMPLE 3: Agent Calling Other Agents (Subagents)")
    print("="*60)

    print("""
🎭 SUBAGENT PATTERN:
   ├─ One agent (parent) calls other agents (children)
   ├─ Parent combines their outputs
   ├─ Children are "subagents" that do specialized tasks
   └─ This is what your MasterConcierge ACTUALLY does!

Example flow:
    User Input
        ↓
    MasterConcierge (Parent Agent)
        ├─ Calls WonderScoutAgent (Subagent #1)
        ├─ Calls ItineraryArchitectAgent (Subagent #2)
        ├─ Calls CultureChefAgent (Subagent #3)
        ├─ Calls SafetyGuardianAgent (Subagent #4)
        │
        └─ Receives all 4 results
          → Combines them
          → Sends combined to LLM one more time
          → Returns final guide

═════════════════════════════════════════════════════════════════
    """)

    # Let's mimic what MasterConcierge does:
    from agents.base_agent import BaseAgent

    class SimpleCoordinatorAgent(BaseAgent):
        """A parent agent that calls subagents"""

        def __init__(self):
            super().__init__(
                name="SimpleCoordinator",
                emoji="🎯",
                role="Coordinator",
                system_instruction=(
                    "You coordinate travel planning. "
                    "You get reports from specialists and synthesize them."
                )
            )
            # ← Create subagents as attributes
            self.weather_subagent = WeatherAgent()
            self.budget_subagent = BudgetAgent()
            self.quote_subagent = SimpleQuoteAgent()

        def run(self, destination: str, days: int) -> str:
            """Coordinate all subagents"""
            
            # ← Call subagents and collect their outputs
            print(f"\n   🎯 Coordinator calling subagents...")
            weather = self.weather_subagent.run(destination=destination)
            budget = self.budget_subagent.run(destination=destination, days=days)
            quote = self.quote_subagent.run(topic="discovery")

            # ← Combine their outputs into a prompt for LLM
            combined = f"""
Weather Report:
{weather}

Budget Report:
{budget}

Inspiration:
{quote}
            """

            # ← Send combined to LLM (final synthesis)
            prompt = f"""You're a master travel coordinator. 
            Synthesize this report into one cohesive travel brief for {destination}:
            
            {combined}
            
            Make it sound like a personal letter from a travel expert."""

            return self.call(prompt)

    # Use the coordinator
    coordinator = SimpleCoordinatorAgent()
    result = coordinator.run(destination="Barcelona", days=4)

    print("\n" + "="*60)
    print("📋 COORDINATED TRAVEL PLAN")
    print("="*60)
    print(result)


def example_4_mixing_patterns():
    """EXAMPLE 4: Mix both patterns together"""
    print("\n" + "="*60)
    print("EXAMPLE 4: Mixing Composition & Subagent Patterns")
    print("="*60)

    print("""
🔀 HYBRID PATTERN:
   
   You can use BOTH patterns:
   
   ├─ COMPOSITION: Direct function calls to agent.run()
   │  └─ Good for: Orchestrating independent agents
   │  └─ Pattern: Call multiple agents in sequence
   │  └─ Combine: Manually merge outputs
   │
   ├─ SUBAGENT: One agent creates & calls other agents
   │  └─ Good for: Complex orchestration
   │  └─ Pattern: Parent agent manages children
   │  └─ Combine: LLM synthesis
   │
   └─ HYBRID: Mix both approaches
      └─ Create agents that are tools
      └─ Create coordinator agents that use those tools
      └─ Get best of both worlds

Example:
    def organize_trip(destination, days):
        # COMPOSITION: Direct calls
        weather = WeatherAgent().run(destination)
        budget = BudgetAgent().run(destination, days)
        
        # SUBAGENT: Use coordinator
        coordinator = SimpleCoordinator()
        final_plan = coordinator.run(destination, days)
        
        # Return combined result
        return {
            'weather': weather,
            'budget': budget,
            'plan': final_plan
        }
    """)

    weather = WeatherAgent()
    budget = BudgetAgent()
    from agents.base_agent import BaseAgent

    class FinalCoordinator(BaseAgent):
        def __init__(self):
            super().__init__(
                name="FinalCoordinator",
                emoji="✨",
                role="Final Coordinator",
                system_instruction="You create the ultimate travel guide."
            )
        
        def run(self, destination: str, days: int, 
                weather_data: str, budget_data: str) -> str:
            prompt = f"""Create ultimate guide for {days} days in {destination}:

Weather:
{weather_data}

Budget:
{budget_data}

Write a compelling travel guide."""
            return self.call(prompt)

    destination = "Rome"
    days = 3

    # COMPOSITION: Direct tool calls
    weather_result = weather.run(destination=destination, month="October")
    budget_result = budget.run(destination=destination, days=days)

    # SUBAGENT: Use coordinator
    coordinator = FinalCoordinator()
    final_result = coordinator.run(
        destination=destination,
        days=days,
        weather_data=weather_result,
        budget_data=budget_result
    )

    print(f"\n🌍 HYBRID TRIP PLAN: {destination}")
    print("="*60)
    print(final_result)


def example_5_understand_your_current_system():
    """EXAMPLE 5: How your actual system works"""
    print("\n" + "="*60)
    print("EXAMPLE 5: How Your Current System Works")
    print("="*60)

    print("""
🏗️ YOUR ACTUAL ARCHITECTURE:

main.py (entry point)
    └─ Imports: All 5 agents
    │
    ├─ Creates WonderScoutAgent() ← Tool/Subagent #1
    ├─ Creates ItineraryArchitectAgent() ← Tool/Subagent #2
    ├─ Creates CultureChefAgent() ← Tool/Subagent #3
    ├─ Creates SafetyGuardianAgent() ← Tool/Subagent #4
    │
    └─ Creates MasterConciergeAgent() ← Parent/Orchestrator
       ├─ Calls subagent #1 (WonderScout)
       ├─ Calls subagent #2 (ItineraryArchitect)
       ├─ Calls subagent #3 (CultureChef)
       ├─ Calls subagent #4 (SafetyGuardian)
       │
       └─ Receives all 4 reports
          → Combines them
          → Sends to Groq LLM
          → Returns final guide

===============================================================

CODE STRUCTURE:

main.py:
    scout = WonderScoutAgent()
    itinerary = ItineraryArchitectAgent()
    culture = CultureChefAgent()
    safety = SafetyGuardianAgent()
    
    # COMPOSITION: Call each as a tool
    scout_report = scout.run(destination)
    itinerary_report = itinerary.run(destination)
    culture_report = culture.run(destination)
    safety_report = safety.run(destination)
    
    # SUBAGENT: Pass all to master
    concierge = MasterConciergeAgent()
    final = concierge.run(
        destination,
        days,
        all_reports={...}  ← Subagent synthesis
    )

===============================================================

YOU'RE USING BOTH PATTERNS:

✓ COMPOSITION: main.py creates multiple agents & calls them
✓ SUBAGENT: MasterConcierge receives their outputs & synthesizes

This is the BEST pattern for travel planning!
    """)

    from agents.wonder_scout import WonderScoutAgent
    from agents.master_concierge import MasterConciergeAgent

    print("\n🔄 YOUR ACTUAL FLOW (Simplified):\n")

    scout = WonderScoutAgent()
    print("1️⃣ main.py creates WonderScout agent")
    print("   └─ scout = WonderScoutAgent()")

    print("\n2️⃣ main.py calls scout as a tool")
    result = scout.run(destination="Venice")
    print(f"   └─ scout.run('Venice') → ✅ Got report\n")

    print("3️⃣ main.py creates MasterConcierge agent")
    print("   └─ concierge = MasterConciergeAgent()")

    print("\n4️⃣ main.py calls concierge to synthesize")
    print("   └─ concierge.run(..., all_reports={...})")
    print("   └─ Concierge internally:")
    print("      • Receives all specialist reports")
    print("      • Sends combined report to LLM")
    print("      • Returns final synthesized guide")


def main():
    print("""
╔══════════════════════════════════════════════════════════════╗
║  🎓 AGENTS AS TOOLS & SUBAGENTS                            ║
║                                                              ║
║  Learn how to:                                              ║
║  ✓ Import agents                                           ║
║  ✓ Use agents as tools (call them as functions)            ║
║  ✓ Create coordinator agents                               ║
║  ✓ Composition vs Subagent patterns                        ║
║  ✓ Understand your actual system architecture              ║
╚══════════════════════════════════════════════════════════════╝
    """)

    example_1_single_agent_as_tool()
    example_2_multiple_agents_as_tools()
    example_3_agent_calling_agents()
    example_4_mixing_patterns()
    example_5_understand_your_current_system()

    print("\n" + "="*60)
    print("✅ Learning Complete!")
    print("="*60)
    print("""
🎯 YOU NOW UNDERSTAND:

   ✓ How to IMPORT agents
   ✓ How to USE agents as "tools"
   ✓ COMPOSITION: Call multiple agents independently
   ✓ SUBAGENT: One agent calls other agents
   ✓ How your MasterConcierge works (both patterns)
   ✓ How to build complex multi-agent systems

🚀 NEXT STEPS:

   1. Create a new agent that uses WeatherAgent + BudgetAgent
   2. Try building a coordinator agent
   3. Study how MasterConciergeAgent works in detail
   4. Build your own multi-agent system

Happy coding! 🎉
    """)


if __name__ == "__main__":
    main()
